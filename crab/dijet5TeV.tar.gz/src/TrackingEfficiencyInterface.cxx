#include "TrackingEfficiencyInterface.h"

TrackingEfficiencyInterface::~TrackingEfficiencyInterface(){
  
}
