#include "../../plotting/JDrawer.h"

void closureDrawer(){
  TFile *closureFile = TFile::Open("Closure.root");
  TH1D *generatorLevelPt = (TH1D*) closureFile->Get("gen_pt");
  TH1D *correctedPt = (TH1D*) closureFile->Get("finalCorr_pt");
  TH1D *ratio = (TH1D*) correctedPt->Clone("ratio");
  ratio->Divide(generatorLevelPt);
  
  generatorLevelPt->SetLineColor(kRed);


  JDrawer *drawer = new JDrawer();
  drawer->SetDefaultAppearanceSplitCanvas();
  drawer->CreateSplitCanvas();
  drawer->SetLogY(true);
  drawer->DrawHistogramToUpperPad(correctedPt,"p_{T}","#frac{dN}{dp_{T}}"," ");
  generatorLevelPt->Draw("same");

  drawer->SetLogY(false);
  drawer->DrawHistogramToLowerPad(ratio,"p_{T}","Reco/Gen", " ");

}
